// file: SphereClick.cs
using UnityEngine;
using System.Collections;

public class SphereClick : MonoBehaviour
{
	private void OnMouseDown() {
        Destroy(gameObject);

		if( gameObject.CompareTag("blue") )
			GotoNextLevel();
	}
	
	private void GotoNextLevel() {
		int level = Application.loadedLevel + 1;
        Application.LoadLevel(level);
    }
}