// file: MenuEnd.cs
using UnityEngine;
using System.Collections;

public class MenuEnd : MonoBehaviour
{
	private void OnGUI() {
		string congrats = "Congratulations. You have finished the game";
		GUILayout.Label(congrats);

		bool mainMenuButtonClicked = GUILayout.Button("Main Menu");
		if( mainMenuButtonClicked )
            Application.LoadLevel(0);
    }
}