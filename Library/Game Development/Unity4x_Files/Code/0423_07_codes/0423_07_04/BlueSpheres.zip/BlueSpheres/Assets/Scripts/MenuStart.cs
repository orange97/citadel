// file: MenuStart.cs
using UnityEngine;
using System.Collections;

public class MenuStart : MonoBehaviour
{
	private void OnGUI() {
		string rules = "Easiest Game Ever -- Click the blue spheres to advance.";
        GUILayout.Label(rules);

		WelcomeGUI();
	}
	
	private void WelcomeGUI() {
		string welcomeMessage = "Welcome";
        GUILayout.Label(welcomeMessage);
		
		bool playButtonClicked = GUILayout.Button("Play");
		
		if( playButtonClicked )
			Application.LoadLevel(1);
	}
}