<?php
/**
* Language file variables for the logout page.
*
* @see GetLang
*
* @version     $Id: logout.php,v 1.5 2007/11/01 02:48:20 chris Exp $
* @author Chris <chris@interspire.com>
*
* @package SendStudio
* @subpackage Language
*/

/**
* Here are all of the variables for the logout area... Please backup before you start!
*/
define('LNG_LogoutSuccessful', 'You have been logged out successfully');
?>
