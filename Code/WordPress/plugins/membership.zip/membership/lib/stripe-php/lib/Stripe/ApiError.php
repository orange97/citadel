<?php

class M2_Stripe_ApiError extends M2_Stripe_Error
{
}
