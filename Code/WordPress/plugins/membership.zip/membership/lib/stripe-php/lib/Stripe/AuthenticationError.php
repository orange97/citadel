<?php

class M2_Stripe_AuthenticationError extends M2_Stripe_Error
{
}
