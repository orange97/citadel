<?php

class M2_Stripe_ApiConnectionError extends M2_Stripe_Error
{
}
