<?php

class M2_Mailchimp_Neapolitan {
    public function __construct(M2_Mailchimp $master) {
        $this->master = $master;
    }

}


